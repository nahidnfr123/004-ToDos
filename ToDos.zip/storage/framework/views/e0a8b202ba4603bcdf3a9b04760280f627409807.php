<?php echo e($slot); ?>

<?php /**PATH E:\work\@_PROJECTS\002-ToDora-(19-3-2021)\ToDora\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>