<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo e(Config::get('app.name', 'Todo App')); ?></title>

    <link href="<?php echo e(asset('dist/css/app.css')); ?>" rel="stylesheet">
</head>
<body class="bg-gray-100 antialiased dark:bg-gray-900">
<div id="app">

</div>

<script src="<?php echo e(asset('dist/js/app.js')); ?>" defer></script>
<script>
    if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.querySelector('html').classList.add('dark')
    } else {
        document.querySelector('html').classList.remove('dark')
    }

    // Whenever the user explicitly chooses light mode
    localStorage.theme = 'light'

    // Whenever the user explicitly chooses dark mode
    localStorage.theme = 'dark'

    // Whenever the user explicitly chooses to respect the OS preference
    localStorage.removeItem('theme')
</script>

</body>
</html>
<?php /**PATH E:\@Projects\01-Todo-App\resources\views/index.blade.php ENDPATH**/ ?>