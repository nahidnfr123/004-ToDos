<?php echo e($slot); ?>

<?php /**PATH E:\work\@Projects\01-Todo-App\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>