(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[6],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/assets/js/views/auth/ResetPassword.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/assets/js/views/auth/ResetPassword.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _store_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../store/auth */ "./resources/assets/js/store/auth.js");


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      credentials: {
        email: "",
        password: "",
        password_confirmation: "",
        token: ""
      },
      errors: {},
      processing: false,
      btnDisabled: false
    };
  },
  mounted: function mounted() {
    if (this.$route.params.token) {
      this.credentials.token = this.$route.params.token;
    } else {
      this.$store.dispatch('snackbar/addSnack', {
        color: 'red-500',
        msg: 'Password reset token is missing.'
      }, {
        root: true
      });
      this.$router.replace({
        name: 'ForgotPassword'
      });
    }
  },
  methods: _objectSpread(_objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])({
    resetPassword: 'auth/resetPassword',
    clearAuthError: 'auth/clearError'
  })), {}, {
    resetPasswordSubmit: function resetPasswordSubmit() {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var __this;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                __this = _this;
                __this.processing = true;

                __this.$Progress.start();

                __this.errors = {};

                __this.clearAuthError(); /// If error is not cleared in VueX auth state... Home page is not shown on successful login ...


                if (!__this.credentials.email.trim()) __this.errors.email = 'Email is required!';

                if (!__this.credentials.password.trim()) {
                  __this.errors.password = 'Password is required!';
                } else if (__this.credentials.password.trim().length < 8) {
                  __this.errors.password = 'Password should be at least 8 characters!';
                } else if (__this.credentials.password.trim() !== __this.credentials.password_confirmation.trim()) {
                  __this.errors.password = 'Password confirmation does not match!';
                }

                if (!Object.keys(__this.errors).length) {
                  _context.next = 11;
                  break;
                }

                __this.$Progress.fail();

                __this.processing = false;
                return _context.abrupt("return");

              case 11:
                _context.next = 13;
                return _this.resetPassword(_this.credentials)["finally"](function () {
                  __this.processing = false;
                });

              case 13:
                if (!(_store_auth__WEBPACK_IMPORTED_MODULE_2__["default"].state.error != null)) {
                  _context.next = 17;
                  break;
                }

                __this.$Progress.fail();

                __this.errors = _store_auth__WEBPACK_IMPORTED_MODULE_2__["default"].state.error;
                return _context.abrupt("return");

              case 17:
                __this.formDisabled = true;
                _context.next = 20;
                return _this.$router.replace({
                  name: 'Login'
                });

              case 20:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    }
  })
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/assets/js/views/auth/ResetPassword.vue?vue&type=template&id=ed663394&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/assets/js/views/auth/ResetPassword.vue?vue&type=template&id=ed663394& ***!
  \***********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass:
        "w-24 min-w-max mx-auto max-w-prose bg-gray-200 shadow-xl rounded-lg my-10 place-content-center lg:min-w-max md:w-auto dark:bg-gray-800",
      staticStyle: { "min-width": "340px!important" }
    },
    [
      _c(
        "h1",
        {
          staticClass:
            "text-center text-gray-800 py-4 text-2xl mt-2 dark:text-gray-300"
        },
        [_vm._v("Reset Password")]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "bg-gray-200 pt-4 pb-16 dark:bg-gray-800" }, [
        _c(
          "div",
          { staticClass: "w-4/5 mx-auto text-gray-800 dark:text-gray-300" },
          [
            _c(
              "form",
              {
                attrs: { method: "post", autofocus: "autofocus" },
                on: {
                  submit: function($event) {
                    $event.stopPropagation()
                    $event.preventDefault()
                    return _vm.resetPasswordSubmit($event)
                  }
                }
              },
              [
                _c("Custom_Text_Input", {
                  staticClass: "mb-4",
                  attrs: {
                    label: "Email",
                    id: "email",
                    type: "email",
                    placeholder: "example@email.com",
                    error:
                      _vm.errors.email && Array.isArray(_vm.errors.email)
                        ? _vm.errors.email[0]
                        : _vm.errors.email,
                    Add_Input_Class: "h-10 dark:bg-gray-900"
                  },
                  model: {
                    value: _vm.credentials.email,
                    callback: function($$v) {
                      _vm.$set(_vm.credentials, "email", $$v)
                    },
                    expression: "credentials.email"
                  }
                }),
                _vm._v(" "),
                _c("Custom_Text_Input", {
                  staticClass: "mb-4",
                  attrs: {
                    label: "Password",
                    id: "password",
                    type: "password",
                    placeholder: "********",
                    error:
                      _vm.errors.password && Array.isArray(_vm.errors.password)
                        ? _vm.errors.password[0]
                        : _vm.errors.password,
                    Add_Input_Class: "h-10 dark:bg-gray-900"
                  },
                  model: {
                    value: _vm.credentials.password,
                    callback: function($$v) {
                      _vm.$set(_vm.credentials, "password", $$v)
                    },
                    expression: "credentials.password"
                  }
                }),
                _vm._v(" "),
                _c("Custom_Text_Input", {
                  staticClass: "mb-4",
                  attrs: {
                    label: "Password Confirmation",
                    id: "password_confirmation",
                    type: "password",
                    placeholder: "********",
                    Add_Input_Class: "h-10 dark:bg-gray-900"
                  },
                  model: {
                    value: _vm.credentials.password_confirmation,
                    callback: function($$v) {
                      _vm.$set(_vm.credentials, "password_confirmation", $$v)
                    },
                    expression: "credentials.password_confirmation"
                  }
                }),
                _vm._v(" "),
                _c("Custom_Text_Input", {
                  staticClass: "invisible",
                  attrs: {
                    id: "token",
                    type: "text",
                    placeholder: "token",
                    hidden: true
                  },
                  model: {
                    value: _vm.credentials.token,
                    callback: function($$v) {
                      _vm.$set(_vm.credentials, "token", $$v)
                    },
                    expression: "credentials.token"
                  }
                }),
                _vm._v(" "),
                _c(
                  "Custom_Loading_Button",
                  {
                    attrs: {
                      Add_Input_Class:
                        "mb-4 mt-6 block mx-auto uppercase rounded",
                      processing: _vm.processing,
                      disabled: _vm.btnDisabled
                    },
                    on: { button_clicked: _vm.resetPasswordSubmit }
                  },
                  [_c("span", [_vm._v("Reset password")])]
                )
              ],
              1
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "text-center mt-4 text-gray-800 dark:text-gray-300" },
          [
            _c(
              "router-link",
              { staticClass: "text-blue-500", attrs: { to: "/login" } },
              [_vm._v("Back to login.")]
            )
          ],
          1
        )
      ])
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/assets/js/views/auth/ResetPassword.vue":
/*!**********************************************************!*\
  !*** ./resources/assets/js/views/auth/ResetPassword.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ResetPassword_vue_vue_type_template_id_ed663394___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ResetPassword.vue?vue&type=template&id=ed663394& */ "./resources/assets/js/views/auth/ResetPassword.vue?vue&type=template&id=ed663394&");
/* harmony import */ var _ResetPassword_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ResetPassword.vue?vue&type=script&lang=js& */ "./resources/assets/js/views/auth/ResetPassword.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ResetPassword_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ResetPassword_vue_vue_type_template_id_ed663394___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ResetPassword_vue_vue_type_template_id_ed663394___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/js/views/auth/ResetPassword.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/assets/js/views/auth/ResetPassword.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/assets/js/views/auth/ResetPassword.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ResetPassword.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/assets/js/views/auth/ResetPassword.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/assets/js/views/auth/ResetPassword.vue?vue&type=template&id=ed663394&":
/*!*****************************************************************************************!*\
  !*** ./resources/assets/js/views/auth/ResetPassword.vue?vue&type=template&id=ed663394& ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_template_id_ed663394___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ResetPassword.vue?vue&type=template&id=ed663394& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/assets/js/views/auth/ResetPassword.vue?vue&type=template&id=ed663394&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_template_id_ed663394___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_template_id_ed663394___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);