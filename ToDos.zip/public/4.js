(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[4],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _store_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../store/auth */ "./resources/assets/js/store/auth.js");


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ForgetPassword',
  data: function data() {
    return {
      credentials: {
        email: ''
      },
      errors: {},
      emailSent: false,
      formDisabled: false,
      processing: false,
      timerInterval: null,
      countdownTimer: null
    };
  },
  methods: _objectSpread(_objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])({
    forgotPassword: 'auth/forgotPassword',
    clearAuthError: 'auth/clearError'
  })), {}, {
    sendResetLink: function sendResetLink() {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var __this;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                __this = _this;
                __this.processing = true;

                __this.$Progress.start();

                __this.errors = {};

                __this.clearAuthError(); /// If error is not cleared in VueX auth state... Home page is not shown on successful login ...


                if (!__this.credentials.email.trim()) __this.errors.email = 'Email is required!';

                if (!Object.keys(__this.errors).length) {
                  _context.next = 10;
                  break;
                }

                __this.$Progress.fail();

                __this.processing = false;
                return _context.abrupt("return");

              case 10:
                _context.next = 12;
                return _this.forgotPassword(_this.credentials)["finally"](function () {
                  __this.processing = false;
                });

              case 12:
                if (!(_store_auth__WEBPACK_IMPORTED_MODULE_2__["default"].state.error != null)) {
                  _context.next = 16;
                  break;
                }

                __this.$Progress.fail();

                __this.errors = _store_auth__WEBPACK_IMPORTED_MODULE_2__["default"].state.error;
                return _context.abrupt("return");

              case 16:
                __this.formDisabled = true;

                __this.startTimer();

              case 18:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    startTimer: function startTimer() {
      var _this2 = this;

      var TIME_LIMIT = 60;
      var timePassed = 0;
      this.countdownTimer = TIME_LIMIT;
      this.timerInterval = setInterval(function () {
        timePassed += 1;
        _this2.countdownTimer = TIME_LIMIT - timePassed;

        if (_this2.countdownTimer == 0) {
          _this2.onTimesUp();
        }
      }, 1000);
    },
    onTimesUp: function onTimesUp() {
      clearInterval(this.timerInterval);
      this.formDisabled = false;
      this.countdownTimer = null;
      this.emailSent = true;
    }
  })
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=template&id=1b0d2d3c&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=template&id=1b0d2d3c& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass:
        "w-24 min-w-max mx-auto max-w-prose bg-gray-200 shadow-xl rounded-lg my-10 place-content-center lg:min-w-max md:w-auto dark:bg-gray-800",
      staticStyle: { "min-width": "340px!important" }
    },
    [
      _c(
        "h1",
        {
          staticClass:
            "text-center text-gray-800 py-4 text-2xl mt-2 dark:text-gray-300"
        },
        [_vm._v("Reset Password")]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "bg-gray-200 pt-4 pb-16 dark:bg-gray-800" }, [
        _c(
          "div",
          { staticClass: "w-4/5 mx-auto text-gray-800 dark:text-gray-300" },
          [
            _c(
              "form",
              {
                attrs: { method: "post", autofocus: "autofocus" },
                on: {
                  submit: function($event) {
                    $event.stopPropagation()
                    $event.preventDefault()
                    return _vm.sendResetLink($event)
                  }
                }
              },
              [
                _c("Custom_Text_Input", {
                  staticClass: "mb-4",
                  attrs: {
                    label: "Email",
                    id: "email",
                    type: "email",
                    placeholder: "example@email.com",
                    error:
                      _vm.errors.email && Array.isArray(_vm.errors.email)
                        ? _vm.errors.email[0]
                        : _vm.errors.email,
                    Add_Input_Class: "h-10 dark:bg-gray-900",
                    disabled: _vm.formDisabled
                  },
                  model: {
                    value: _vm.credentials.email,
                    callback: function($$v) {
                      _vm.$set(_vm.credentials, "email", $$v)
                    },
                    expression: "credentials.email"
                  }
                }),
                _vm._v(" "),
                _c(
                  "Custom_Loading_Button",
                  {
                    attrs: {
                      Add_Input_Class:
                        "mb-4 mt-6 block mx-auto uppercase rounded",
                      processing: _vm.processing,
                      disabled: _vm.formDisabled
                    },
                    on: { button_clicked: _vm.sendResetLink }
                  },
                  [
                    !_vm.emailSent
                      ? _c("span", [_vm._v("Send password reset link")])
                      : _c("span", [_vm._v("Resend password reset link")])
                  ]
                )
              ],
              1
            ),
            _vm._v(" "),
            _vm.countdownTimer
              ? _c(
                  "div",
                  {
                    staticClass:
                      "text-center text-xs mt-2 text-gray-800 dark:text-gray-300"
                  },
                  [
                    _vm._v(
                      "\n                Email sent successfully. You can retry in " +
                        _vm._s(_vm.countdownTimer) +
                        " sec.\n            "
                    )
                  ]
                )
              : _vm._e()
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "text-center mt-4 text-gray-800 dark:text-gray-300" },
          [
            _c(
              "router-link",
              { staticClass: "text-blue-500", attrs: { to: "/login" } },
              [_vm._v("Back to login.")]
            )
          ],
          1
        )
      ])
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/assets/js/views/auth/ForgotPassword.vue":
/*!***********************************************************!*\
  !*** ./resources/assets/js/views/auth/ForgotPassword.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ForgotPassword_vue_vue_type_template_id_1b0d2d3c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ForgotPassword.vue?vue&type=template&id=1b0d2d3c& */ "./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=template&id=1b0d2d3c&");
/* harmony import */ var _ForgotPassword_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ForgotPassword.vue?vue&type=script&lang=js& */ "./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ForgotPassword_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ForgotPassword_vue_vue_type_template_id_1b0d2d3c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ForgotPassword_vue_vue_type_template_id_1b0d2d3c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/js/views/auth/ForgotPassword.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ForgotPassword.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=template&id=1b0d2d3c&":
/*!******************************************************************************************!*\
  !*** ./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=template&id=1b0d2d3c& ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_template_id_1b0d2d3c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ForgotPassword.vue?vue&type=template&id=1b0d2d3c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/assets/js/views/auth/ForgotPassword.vue?vue&type=template&id=1b0d2d3c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_template_id_1b0d2d3c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_template_id_1b0d2d3c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);