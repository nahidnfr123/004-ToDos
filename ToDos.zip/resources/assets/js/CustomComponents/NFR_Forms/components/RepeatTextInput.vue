<template>
    <div>

    </div>
</template>

<script>

export default {
    name: "RepeatTextInput",
    props:{},
    data(){
        return{

        }
    },
    methods:{

    }
}
</script>
