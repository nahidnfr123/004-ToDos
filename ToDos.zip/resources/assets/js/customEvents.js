let Fire = new Vue()
window.Fire = Fire;
